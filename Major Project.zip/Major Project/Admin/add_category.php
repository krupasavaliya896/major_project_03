<!doctype html>
<!--
* Tabler - Premium and Open Source dashboard template with responsive and high quality UI.
* @version 1.0.0-beta17
* @link https://tabler.io
* Copyright 2018-2023 The Tabler Authors
* Copyright 2018-2023 codecalm.net Paweł Kuna
* Licensed under MIT (https://github.com/tabler/tabler/blob/master/LICENSE)
-->
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Form elements - Tabler - Premium and Open Source dashboard template with responsive and high quality UI.</title>
    <!-- CSS files -->
    <link href="./dist/css/tabler.min.css?1674944402" rel="stylesheet" />
    <link href="./dist/css/tabler-flags.min.css?1674944402" rel="stylesheet" />
    <link href="./dist/css/tabler-payments.min.css?1674944402" rel="stylesheet" />
    <link href="./dist/css/tabler-vendors.min.css?1674944402" rel="stylesheet" />
    <link href="./dist/css/demo.min.css?1674944402" rel="stylesheet" />
    <style>
        @import url('https://rsms.me/inter/inter.css');

        :root {
            --tblr-font-sans-serif: 'Inter Var', -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif;
        }

        body {
            font-feature-settings: "cv03", "cv04", "cv11";
        }
    </style>
</head>

<body>
    <script src="./dist/js/demo-theme.min.js?1674944402"></script>
    <div class="page">
        <!-- Navbar -->
        <?php
        include('nav.php')
        ?>
        <div class="page-wrapper">
            <!-- Page header -->
            <div class="page-header d-print-none">
                <div class="container-xl">
                    <div class="row g-2 align-items-center">
                        <div class="col">
                            <h2 class="page-title">
                                Add New Category
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Page body -->
            <div class="page-body">
                <div class="container-xl">
                    <div class="row row-cards">
                        <div class="col-12">

                            <form action="#" method="POST" class="card">
                                <?php
                                if (isset($_POST['ok'])) {
                                    //error_reporting(0);
                                    include("connection.php");
                                    $query = "insert into category(id,name,description) values('NULL','" . $_POST['category_name'] . "','" . $_POST['description'] . "')";
                                    $d = mysqli_query($con, $query);
                                    if ($d) {
                                        echo "<script>alert('You Singup is Done!')</script>";
                                    } else {
                                        echo "<script>alert('Something went wrong')</script>";
                                    }
                                }

                                ?>
                                <div class="card-header">
                                    <h4 class="card-title">Form</h4>
                                </div>
                                <div class="card-body">
                                    <div class="col-lg-12">
                                        <div class="row row-cards">
                                            <div class="col-12">
                                                <form class="card">
                                                    <div class="card-body">
                                                        <div class="row row-cards">


                                                            <div class="col-sm-6 col-md-4">
                                                                <div class="mb-3">
                                                                    <label class="form-label">Category Name</label>
                                                                    <input type="text" class="form-control" placeholder="Category Name" id="category_name" name="category_name">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="mb-3 mb-0">
                                                                    <label class="form-label">Description</label>
                                                                    <textarea rows="5" class="form-control" placeholder="Here can be your category description" id="description" name="description"></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="card-footer text-end">
                                                        <input type="submit" class="btn btn-primary" value="Add new Category" name="ok">
                                                    </div>
                                                </form>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                    <footer class="footer footer-transparent d-print-none">
                        <div class="container-xl">
                            <div class="row text-center align-items-center flex-row-reverse">
                                <div class="col-lg-auto ms-lg-auto">
                                    <ul class="list-inline list-inline-dots mb-0">
                                        <li class="list-inline-item"><a href="./docs/" class="link-secondary">Documentation</a></li>
                                        <li class="list-inline-item"><a href="./license.php" class="link-secondary">License</a></li>
                                        <li class="list-inline-item"><a href="https://github.com/tabler/tabler" target="_blank" class="link-secondary" rel="noopener">Source code</a></li>
                                        <li class="list-inline-item">
                                            <a href="https://github.com/sponsors/codecalm" target="_blank" class="link-secondary" rel="noopener">
                                                <!-- Download SVG icon from http://tabler-icons.io/i/heart -->
                                                <svg xmlns="http://www.w3.org/2000/svg" class="icon text-pink icon-filled icon-inline" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                                    <path d="M19.5 12.572l-7.5 7.428l-7.5 -7.428a5 5 0 1 1 7.5 -6.566a5 5 0 1 1 7.5 6.572" />
                                                </svg>
                                                Sponsor
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-12 col-lg-auto mt-3 mt-lg-0">
                                    <ul class="list-inline list-inline-dots mb-0">
                                        <li class="list-inline-item">
                                            Copyright &copy; 2023
                                            <a href="." class="link-secondary">Tabler</a>.
                                            All rights reserved.
                                        </li>
                                        <li class="list-inline-item">
                                            <a href="./changelog.php" class="link-secondary" rel="noopener">
                                                v1.0.0-beta17
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </footer>
                </div>
            </div>
            <!-- Libs JS -->
            <script src="./dist/libs/nouislider/dist/nouislider.min.js?1674944402" defer></script>
            <script src="./dist/libs/litepicker/dist/litepicker.js?1674944402" defer></script>
            <script src="./dist/libs/tom-select/dist/js/tom-select.base.min.js?1674944402" defer></script>
            <!-- Tabler Core -->
            <script src="./dist/js/tabler.min.js?1674944402" defer></script>
            <script src="./dist/js/demo.min.js?1674944402" defer></script>
            <script>
                // @formatter:off
                document.addEventListener("DOMContentLoaded", function() {
                    window.noUiSlider && (noUiSlider.create(document.getElementById('range-simple'), {
                        start: 20,
                        connect: [true, false],
                        step: 10,
                        range: {
                            min: 0,
                            max: 100
                        }
                    }));
                });
                // @formatter:on
            </script>
            <script>
                // @formatter:off
                document.addEventListener("DOMContentLoaded", function() {
                    window.noUiSlider && (noUiSlider.create(document.getElementById('range-connect'), {
                        start: [60, 90],
                        connect: [false, true, false],
                        step: 10,
                        range: {
                            min: 0,
                            max: 100
                        }
                    }));
                });
                // @formatter:on
            </script>
            <script>
                // @formatter:off
                document.addEventListener("DOMContentLoaded", function() {
                    window.noUiSlider && (noUiSlider.create(document.getElementById('range-color'), {
                        start: 40,
                        connect: [true, false],
                        step: 10,
                        range: {
                            min: 0,
                            max: 100
                        }
                    }));
                });
                // @formatter:on
            </script>
            <script>
                // @formatter:off
                document.addEventListener("DOMContentLoaded", function() {
                    window.Litepicker && (new Litepicker({
                        element: document.getElementById('datepicker-default'),
                        buttonText: {
                            previousMonth: `<!-- Download SVG icon from http://tabler-icons.io/i/chevron-left -->
    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 6l-6 6l6 6" /></svg>`,
                            nextMonth: `<!-- Download SVG icon from http://tabler-icons.io/i/chevron-right -->
    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 6l6 6l-6 6" /></svg>`,
                        },
                    }));
                });
                // @formatter:on
            </script>
            <script>
                // @formatter:off
                document.addEventListener("DOMContentLoaded", function() {
                    window.Litepicker && (new Litepicker({
                        element: document.getElementById('datepicker-icon'),
                        buttonText: {
                            previousMonth: `<!-- Download SVG icon from http://tabler-icons.io/i/chevron-left -->
    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 6l-6 6l6 6" /></svg>`,
                            nextMonth: `<!-- Download SVG icon from http://tabler-icons.io/i/chevron-right -->
    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 6l6 6l-6 6" /></svg>`,
                        },
                    }));
                });
                // @formatter:on
            </script>
            <script>
                // @formatter:off
                document.addEventListener("DOMContentLoaded", function() {
                    window.Litepicker && (new Litepicker({
                        element: document.getElementById('datepicker-icon-prepend'),
                        buttonText: {
                            previousMonth: `<!-- Download SVG icon from http://tabler-icons.io/i/chevron-left -->
    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 6l-6 6l6 6" /></svg>`,
                            nextMonth: `<!-- Download SVG icon from http://tabler-icons.io/i/chevron-right -->
    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 6l6 6l-6 6" /></svg>`,
                        },
                    }));
                });
                // @formatter:on
            </script>
            <script>
                // @formatter:off
                document.addEventListener("DOMContentLoaded", function() {
                    window.Litepicker && (new Litepicker({
                        element: document.getElementById('datepicker-inline'),
                        buttonText: {
                            previousMonth: `<!-- Download SVG icon from http://tabler-icons.io/i/chevron-left -->
    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 6l-6 6l6 6" /></svg>`,
                            nextMonth: `<!-- Download SVG icon from http://tabler-icons.io/i/chevron-right -->
    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 6l6 6l-6 6" /></svg>`,
                        },
                        inlineMode: true,
                    }));
                });
                // @formatter:on
            </script>
            <script>
                // @formatter:off
                document.addEventListener("DOMContentLoaded", function() {
                    var el;
                    window.TomSelect && (new TomSelect(el = document.getElementById('select-tags'), {
                        copyClassesToDropdown: false,
                        dropdownClass: 'dropdown-menu ts-dropdown',
                        optionClass: 'dropdown-item',
                        controlInput: '<input>',
                        render: {
                            item: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                            option: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                        },
                    }));
                });
                // @formatter:on
            </script>
            <script>
                // @formatter:off
                document.addEventListener("DOMContentLoaded", function() {
                    var el;
                    window.TomSelect && (new TomSelect(el = document.getElementById('select-tags-advanced'), {
                        copyClassesToDropdown: false,
                        dropdownClass: 'dropdown-menu ts-dropdown',
                        optionClass: 'dropdown-item',
                        controlInput: '<input>',
                        render: {
                            item: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                            option: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                        },
                    }));
                });
                // @formatter:on
            </script>
            <script>
                // @formatter:off
                document.addEventListener("DOMContentLoaded", function() {
                    var el;
                    window.TomSelect && (new TomSelect(el = document.getElementById('select-users'), {
                        copyClassesToDropdown: false,
                        dropdownClass: 'dropdown-menu ts-dropdown',
                        optionClass: 'dropdown-item',
                        controlInput: '<input>',
                        render: {
                            item: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                            option: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                        },
                    }));
                });
                // @formatter:on
            </script>
            <script>
                // @formatter:off
                document.addEventListener("DOMContentLoaded", function() {
                    var el;
                    window.TomSelect && (new TomSelect(el = document.getElementById('select-optgroups'), {
                        copyClassesToDropdown: false,
                        dropdownClass: 'dropdown-menu ts-dropdown',
                        optionClass: 'dropdown-item',
                        controlInput: '<input>',
                        render: {
                            item: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                            option: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                        },
                    }));
                });
                // @formatter:on
            </script>
            <script>
                // @formatter:off
                document.addEventListener("DOMContentLoaded", function() {
                    var el;
                    window.TomSelect && (new TomSelect(el = document.getElementById('select-people'), {
                        copyClassesToDropdown: false,
                        dropdownClass: 'dropdown-menu ts-dropdown',
                        optionClass: 'dropdown-item',
                        controlInput: '<input>',
                        render: {
                            item: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                            option: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                        },
                    }));
                });
                // @formatter:on
            </script>
            <script>
                // @formatter:off
                document.addEventListener("DOMContentLoaded", function() {
                    var el;
                    window.TomSelect && (new TomSelect(el = document.getElementById('select-countries'), {
                        copyClassesToDropdown: false,
                        dropdownClass: 'dropdown-menu ts-dropdown',
                        optionClass: 'dropdown-item',
                        controlInput: '<input>',
                        render: {
                            item: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                            option: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                        },
                    }));
                });
                // @formatter:on
            </script>
            <script>
                // @formatter:off
                document.addEventListener("DOMContentLoaded", function() {
                    var el;
                    window.TomSelect && (new TomSelect(el = document.getElementById('select-labels'), {
                        copyClassesToDropdown: false,
                        dropdownClass: 'dropdown-menu ts-dropdown',
                        optionClass: 'dropdown-item',
                        controlInput: '<input>',
                        render: {
                            item: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                            option: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                        },
                    }));
                });
                // @formatter:on
            </script>
            <script>
                // @formatter:off
                document.addEventListener("DOMContentLoaded", function() {
                    var el;
                    window.TomSelect && (new TomSelect(el = document.getElementById('select-countries-valid'), {
                        copyClassesToDropdown: false,
                        dropdownClass: 'dropdown-menu ts-dropdown',
                        optionClass: 'dropdown-item',
                        controlInput: '<input>',
                        render: {
                            item: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                            option: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                        },
                    }));
                });
                // @formatter:on
            </script>
            <script>
                // @formatter:off
                document.addEventListener("DOMContentLoaded", function() {
                    var el;
                    window.TomSelect && (new TomSelect(el = document.getElementById('select-countries-invalid'), {
                        copyClassesToDropdown: false,
                        dropdownClass: 'dropdown-menu ts-dropdown',
                        optionClass: 'dropdown-item',
                        controlInput: '<input>',
                        render: {
                            item: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                            option: function(data, escape) {
                                if (data.customProperties) {
                                    return '<div><span class="dropdown-item-indicator">' + data.customProperties + '</span>' + escape(data.text) + '</div>';
                                }
                                return '<div>' + escape(data.text) + '</div>';
                            },
                        },
                    }));
                });
                // @formatter:on
            </script>
            <script>
                document.addEventListener("DOMContentLoaded", function() {
                    let sliderTriggerList = [].slice.call(document.querySelectorAll("[data-slider]"));
                    sliderTriggerList.map(function(sliderTriggerEl) {
                        let options = {};
                        if (sliderTriggerEl.getAttribute("data-slider")) {
                            options = JSON.parse(sliderTriggerEl.getAttribute("data-slider"));
                        }
                        let slider = noUiSlider.create(sliderTriggerEl, options);
                        if (options['js-name']) {
                            window[options['js-name']] = slider;
                        }
                    });
                });
            </script>
</body>

</html>