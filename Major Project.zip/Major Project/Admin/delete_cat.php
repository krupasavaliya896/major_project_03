<?php
include('connection.php');
$id=$_REQUEST['id'];
$q="delete from category where id='$id' ";
$result=mysqli_query($con,$q);
if($result)
{
	echo "<script>window.location='update_category.php'</script>";
}
else 
{
	echo "<script>alert('Something Went Wrong')</script>";
}
?>
