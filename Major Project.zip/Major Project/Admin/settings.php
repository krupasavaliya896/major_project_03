<!doctype html>
<!--
* Tabler - Premium and Open Source dashboard template with responsive and high quality UI.
* @version 1.0.0-beta17
* @link https://tabler.io
* Copyright 2018-2023 The Tabler Authors
* Copyright 2018-2023 codecalm.net Paweł Kuna
* Licensed under MIT (https://github.com/tabler/tabler/blob/master/LICENSE)
-->
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <title>Settings - Tabler - Premium and Open Source dashboard template with responsive and high quality UI.</title>
  <!-- CSS files -->
  <link href="./dist/css/tabler.min.css?1674944402" rel="stylesheet" />
  <link href="./dist/css/tabler-flags.min.css?1674944402" rel="stylesheet" />
  <link href="./dist/css/tabler-payments.min.css?1674944402" rel="stylesheet" />
  <link href="./dist/css/tabler-vendors.min.css?1674944402" rel="stylesheet" />
  <link href="./dist/css/demo.min.css?1674944402" rel="stylesheet" />
  <style>
    @import url('https://rsms.me/inter/inter.css');

    :root {
      --tblr-font-sans-serif: 'Inter Var', -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif;
    }

    body {
      font-feature-settings: "cv03", "cv04", "cv11";
    }
  </style>
</head>

<body>
  <script src="./dist/js/demo-theme.min.js?1674944402"></script>
  <div class="page">
    <!-- Navbar -->
    <?php
    include('nav.php')
    ?>
    <div class="page-wrapper">
      <!-- Page header -->
      <div class="page-header d-print-none">
        <div class="container-xl">
          <div class="row g-2 align-items-center">
            <div class="col">
              <h2 class="page-title">
                Account Settings
              </h2>
            </div>
          </div>
        </div>
      </div>
      <!-- Page body -->
      <div class="page-body">
        <div class="container-xl">
          <div class="card">
            <div class="row g-0">

              <div class="col d-flex flex-column">
                <div class="card-body">
                  <h2 class="mb-4">My Account</h2>
                  <h3 class="card-title">Profile Details</h3>
                  <div class="row align-items-center">
                    <div class="col-auto"><span class="avatar avatar-xl" style="background-image: url(./static/avatars/000m.jpg)"></span>
                    </div>
                    <div class="col-auto"><a href="#" class="btn">
                        Change avatar
                      </a></div>
                    <div class="col-auto"><a href="#" class="btn btn-ghost-danger">
                        Delete avatar
                      </a></div>
                  </div>
                  <h3 class="card-title mt-4">Business Profile</h3>
                  <div class="row g-3">
                    <div class="col-md">
                      <div class="form-label">Business Name</div>
                      <input type="text" class="form-control" value="Tabler">
                    </div>
                    <div class="col-md">
                      <div class="form-label">Business ID</div>
                      <input type="text" class="form-control" value="560afc32">
                    </div>
                    <div class="col-md">
                      <div class="form-label">Location</div>
                      <input type="text" class="form-control" value="Peimei, China">
                    </div>
                  </div>
                  <h3 class="card-title mt-4">Email</h3>
                  <p class="card-subtitle">This contact will be shown to others publicly, so choose it carefully.</p>
                  <div>
                    <div class="row g-2">
                      <div class="col-auto">
                        <input type="text" class="form-control w-auto" value="paweluna@howstuffworks.com">
                      </div>
                      <div class="col-auto"><a href="#" class="btn">
                          Change
                        </a></div>
                    </div>
                  </div>
                </div>
                <div class="card-footer bg-transparent mt-auto">
                  <div class="btn-list justify-content-end">
                    <a href="#" class="btn">
                      Cancel
                    </a>
                    <a href="#" class="btn btn-primary">
                      Submit
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <footer class="footer footer-transparent d-print-none">
        <div class="container-xl">
          <div class="row text-center align-items-center flex-row-reverse">
            <div class="col-lg-auto ms-lg-auto">
              <ul class="list-inline list-inline-dots mb-0">
                <li class="list-inline-item"><a href="./docs/" class="link-secondary">Documentation</a></li>
                <li class="list-inline-item"><a href="./license.php" class="link-secondary">License</a></li>
                <li class="list-inline-item"><a href="https://github.com/tabler/tabler" target="_blank" class="link-secondary" rel="noopener">Source code</a></li>
                <li class="list-inline-item">
                  <a href="https://github.com/sponsors/codecalm" target="_blank" class="link-secondary" rel="noopener">
                    <!-- Download SVG icon from http://tabler-icons.io/i/heart -->
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon text-pink icon-filled icon-inline" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                      <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                      <path d="M19.5 12.572l-7.5 7.428l-7.5 -7.428a5 5 0 1 1 7.5 -6.566a5 5 0 1 1 7.5 6.572" />
                    </svg>
                    Sponsor
                  </a>
                </li>
              </ul>
            </div>
            <div class="col-12 col-lg-auto mt-3 mt-lg-0">
              <ul class="list-inline list-inline-dots mb-0">
                <li class="list-inline-item">
                  Copyright &copy; 2023
                  <a href="." class="link-secondary">Tabler</a>.
                  All rights reserved.
                </li>
                <li class="list-inline-item">
                  <a href="./changelog.php" class="link-secondary" rel="noopener">
                    v1.0.0-beta17
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <!-- Libs JS -->
  <!-- Tabler Core -->
  <script src="./dist/js/tabler.min.js?1674944402" defer></script>
  <script src="./dist/js/demo.min.js?1674944402" defer></script>
</body>

</html>